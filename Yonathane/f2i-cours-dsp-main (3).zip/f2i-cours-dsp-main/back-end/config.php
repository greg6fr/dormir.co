<?php 
    $authEmail = "busi.travail@gmail.com";
    $authPassword = "ecmlskjwsjckklsl";
?> 